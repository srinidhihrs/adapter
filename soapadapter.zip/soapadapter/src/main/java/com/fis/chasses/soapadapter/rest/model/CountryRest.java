package com.fis.chasses.soapadapter.rest.model;

public class CountryRest {

    protected String name;
    protected int population;
    protected String capital;
    protected CurrencyRest currency;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public CurrencyRest getCurrency() {
        return currency;
    }

    public void setCurrency(CurrencyRest currency) {
        this.currency = currency;
    }
}
