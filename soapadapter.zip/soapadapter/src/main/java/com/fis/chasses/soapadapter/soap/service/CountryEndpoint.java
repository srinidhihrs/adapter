package com.fis.chasses.soapadapter.soap.service;

import com.fis.chasses.soapadapter.rest.controller.CountryController;
import com.fis.chasses.soapadapter.rest.repository.CountryRepository;
import com.fis.chasses.soapadapter.soap.mapper.SoapRestMapper;
import com.fis.chasses.soapadapter.GetCountryRequest;
import com.fis.chasses.soapadapter.GetCountryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class CountryEndpoint {
    private static final String NAMESPACE_URI = "http://fis.com/chasses/soapadapter";

    private CountryRepository countryRepository;
    private SoapRestMapper soapRestMapper;
    private CountryController countryController;

    @Autowired
    public CountryEndpoint(CountryRepository countryRepository,SoapRestMapper soapRestMapper,CountryController countryController) {
        this.countryRepository = countryRepository;
        this.soapRestMapper = soapRestMapper;
        this.countryController = countryController;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCountryRequest")
    @ResponsePayload
    public GetCountryResponse getCountry(@RequestPayload GetCountryRequest request) {
        return soapRestMapper.buildSoapResponse(countryController.getCountry(soapRestMapper.buildRestRequest(request)));
    }
}
