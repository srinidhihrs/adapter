package com.fis.chasses.soapadapter.rest.repository;


import com.fis.chasses.soapadapter.rest.model.CountryRest;
import com.fis.chasses.soapadapter.rest.model.CurrencyRest;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Component
public class CountryRepository {
    private static final Map<String, CountryRest> countries = new HashMap<>();

    @PostConstruct
    public void initData() {
        CountryRest spain = new CountryRest();
        spain.setName("Spain");
        spain.setCapital("Madrid");
        spain.setCurrency(CurrencyRest.EUR);
        spain.setPopulation(46704314);

        countries.put(spain.getName(), spain);

        CountryRest poland = new CountryRest();
        poland.setName("Poland");
        poland.setCapital("Warsaw");
        poland.setCurrency(CurrencyRest.PLN);
        poland.setPopulation(38186860);

        countries.put(poland.getName(), poland);

        CountryRest uk = new CountryRest();
        uk.setName("United Kingdom");
        uk.setCapital("London");
        uk.setCurrency(CurrencyRest.GBP);
        uk.setPopulation(63705000);

        countries.put(uk.getName(), uk);
    }

    public CountryRest findCountry(String name) {
        Assert.notNull(name, "The country's name must not be null");
        return countries.get(name);
    }
}
