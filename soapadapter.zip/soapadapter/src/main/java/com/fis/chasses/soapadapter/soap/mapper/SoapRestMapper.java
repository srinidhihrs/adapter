package com.fis.chasses.soapadapter.soap.mapper;

import com.fis.chasses.soapadapter.rest.model.CountryRest;
import com.fis.chasses.soapadapter.Country;
import com.fis.chasses.soapadapter.Currency;
import com.fis.chasses.soapadapter.GetCountryRequest;
import com.fis.chasses.soapadapter.GetCountryResponse;
import org.springframework.stereotype.Service;

@Service
public class SoapRestMapper {
    public String buildRestRequest(GetCountryRequest request){
        return request.getName();
    }
    public GetCountryResponse buildSoapResponse(CountryRest countryRest){
        GetCountryResponse response = new GetCountryResponse();
        Country country=new Country();
        country.setName(countryRest.getName());
        country.setCurrency(Currency.fromValue(countryRest.getCurrency().value()));
        country.setCapital(countryRest.getCapital());
        country.setPopulation(countryRest.getPopulation());
        response.setCountry(country);
        return response;
    }
}
