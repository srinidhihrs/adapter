package com.fis.chasses.soapadapter.rest.model;

public enum CurrencyRest {
    GBP,
    EUR,
    PLN;

    public String value() {
        return name();
    }

    public static CurrencyRest fromValue(String v) {
        return valueOf(v);
    }
}
