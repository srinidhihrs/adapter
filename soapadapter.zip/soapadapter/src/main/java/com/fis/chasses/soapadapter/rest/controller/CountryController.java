package com.fis.chasses.soapadapter.rest.controller;

import com.fis.chasses.soapadapter.rest.model.CountryRest;
import com.fis.chasses.soapadapter.rest.repository.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
@Controller
public class CountryController {

    @Autowired
    private CountryRepository repository;
    @PostMapping("/country")
    public CountryRest getCountry(@RequestBody String countryName) {
        return repository.findCountry(countryName);
    }
}
