package com.fis.chasses.soapadapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapadapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
